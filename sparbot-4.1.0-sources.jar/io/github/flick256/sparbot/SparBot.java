package io.github.flick256.sparbot;

import io.github.flick256.sparbot.bot.BotManager;
import io.github.flick256.sparbot.command.SparBotCommand;
import io.github.flick256.sparbot.config.SparBotConfig;
import io.github.flick256.sparbot.debug.DebugOverlay;
import io.github.flick256.sparbot.kit.KitRegistry;
import io.github.flick256.sparbot.match.MatchManager;
import io.github.flick256.sparbot.menu.MenuSync;
import io.github.flick256.sparbot.profile.ProfileRegistry;
import io.github.flick256.sparbot.record.Recorder;
import io.github.flick256.sparbot.record.ReplayManager;
import io.github.flick256.sparbot.stats.StatsTracker;
import io.github.flick256.sparbot.style.PlaystyleRegistry;
import java.nio.file.Path;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * SparBot: PvP sparring bots that behave like real, mortal players, and the Celestial Colosseum with Vaelor
 * under it. Works in singleplayer (the integrated server) and on dedicated servers; since 1.2 it adds items and
 * an entity of its own, so players need it on their client too.
 */
public final class SparBot implements ModInitializer {
	public static final String MOD_ID = "sparbot";
	public static final Logger LOGGER = LoggerFactory.getLogger("SparBot");

	private static SparBotConfig config = new SparBotConfig();
	private static final ProfileRegistry PROFILES = new ProfileRegistry();
	private static final KitRegistry KITS = new KitRegistry();
	private static final BotManager BOTS = new BotManager();
	private static final PlaystyleRegistry STYLES = new PlaystyleRegistry();
	private static final DebugOverlay DEBUG = new DebugOverlay();
	private static final MatchManager MATCHES = new MatchManager();
	private static final Recorder RECORDER = new Recorder();
	private static final ReplayManager REPLAYS = new ReplayManager();
	private static final io.github.flick256.sparbot.career.CareerManager CAREERS = new io.github.flick256.sparbot.career.CareerManager(
		FabricLoader.getInstance().getConfigDir().resolve("sparbot").resolve("career.json"));
	private static final io.github.flick256.sparbot.practice.PracticeWorld PRACTICE = new io.github.flick256.sparbot.practice.PracticeWorld();
	private static final io.github.flick256.sparbot.drill.DrillManager DRILLS = new io.github.flick256.sparbot.drill.DrillManager();
	private static final io.github.flick256.sparbot.kit.PlayerLayouts PLAYER_LAYOUTS = new io.github.flick256.sparbot.kit.PlayerLayouts(
		FabricLoader.getInstance().getConfigDir().resolve("sparbot").resolve("my_layouts"));

	@Override
	public void onInitialize() {
		io.github.flick256.sparbot.content.SparBotContent.register();
		reloadConfigAndProfiles();
		StatsTracker.register();
		MenuSync.register();
		io.github.flick256.sparbot.kit.editor.KitEditor.register();
		DRILLS.register();
		CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, selection) -> SparBotCommand.register(dispatcher));
		ServerLifecycleEvents.SERVER_STARTED.register(server -> {
			reloadKits(server);
			MATCHES.reload(server, configDir().resolve("sparbot"));
			DRILLS.load(configDir().resolve("sparbot"));
			try { CAREERS.load(); }
			catch (java.io.IOException | IllegalArgumentException e) { LOGGER.error("Could not load career progress; existing save was preserved", e); }
			io.github.flick256.sparbot.practice.colosseum.HollowCrown.load(configDir().resolve("sparbot"));
			PRACTICE.onServerStarted(server);
		});
		ServerTickEvents.END_SERVER_TICK.register(BOTS::tick);
		ServerTickEvents.END_SERVER_TICK.register(DEBUG::tick);
		ServerTickEvents.END_SERVER_TICK.register(MATCHES::tick);
		ServerTickEvents.END_SERVER_TICK.register(RECORDER::tick);
		ServerTickEvents.END_SERVER_TICK.register(REPLAYS::tick);
		ServerTickEvents.END_SERVER_TICK.register(PRACTICE::tick);
		ServerTickEvents.END_SERVER_TICK.register(DRILLS::tick);
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> MATCHES.onJoin(handler.player));
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			// A failure in one subsystem must not skip bot disconnects or the other cleanup.
			stopPart("drills", () -> DRILLS.stopAll(server));
			stopPart("colosseum games", () -> PRACTICE.games().stop(server, "the server is stopping"));
			stopPart("Deep encounter", () -> PRACTICE.stopDeep(server));
			stopPart("matches", () -> MATCHES.stopAll(server));
			stopPart("career", CAREERS::stop);
			stopPart("recordings", RECORDER::stopAll);
			stopPart("replays", REPLAYS::stopAll);
			stopPart("bots", () -> BOTS.removeAll("server stopping"));
		});
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> LOGGER.info("SparBot server shutdown complete"));
		LOGGER.info("SparBot {} initialised: {} skill profiles, enabled={}", FabricLoader.getInstance().getModContainer(MOD_ID)
			.map(mod -> mod.getMetadata().getVersion().getFriendlyString()).orElse("?"), PROFILES.ids().size(), config.enabled);
	}

	private static void stopPart(String name, Runnable cleanup) {
		LOGGER.info("SparBot shutdown: stopping {}", name);
		long started = System.nanoTime();
		try {
			cleanup.run();
			LOGGER.info("SparBot shutdown: stopped {} in {} ms", name, (System.nanoTime() - started) / 1_000_000);
		} catch (RuntimeException e) {
			LOGGER.error("SparBot shutdown: failed to stop {}; continuing cleanup", name, e);
		}
	}

	public static void reloadConfigAndProfiles() {
		config = SparBotConfig.load(configDir().resolve("sparbot.json"));
		PROFILES.reload(configDir().resolve("sparbot").resolve("profiles"));
		STYLES.reload(configDir().resolve("sparbot").resolve("playstyles"));
		RECORDER.setDirectory(configDir().resolve("sparbot").resolve("recordings"));
	}

	public static void saveConfig() {
		config.save(configDir().resolve("sparbot.json"));
	}

	public static void reloadKits(MinecraftServer server) {
		KITS.reload(configDir().resolve("sparbot").resolve("kits"), configDir().resolve("sparbot").resolve("layouts"), server.registryAccess());
		LOGGER.info("SparBot kits loaded: {}; layouts: {}", KITS.ids(), KITS.layoutIds());
	}

	private static Path configDir() {
		return FabricLoader.getInstance().getConfigDir();
	}

	/** The kit each player last equipped (for bots to fight them in the same kit). */
	private static final java.util.Map<java.util.UUID, String> PLAYER_KITS = new java.util.concurrent.ConcurrentHashMap<>();

	public static java.util.Map<java.util.UUID, String> playerKits() {
		return PLAYER_KITS;
	}

	/** Players' own hotbar layouts per kit. */
	public static io.github.flick256.sparbot.kit.PlayerLayouts playerLayouts() {
		return PLAYER_LAYOUTS;
	}

	public static SparBotConfig config() {
		return config;
	}

	public static ProfileRegistry profiles() {
		return PROFILES;
	}

	public static KitRegistry kits() {
		return KITS;
	}

	public static PlaystyleRegistry playstyles() {
		return STYLES;
	}

	public static Recorder recorder() {
		return RECORDER;
	}

	public static io.github.flick256.sparbot.career.CareerManager careers() { return CAREERS; }

	public static ReplayManager replays() {
		return REPLAYS;
	}

	public static io.github.flick256.sparbot.practice.PracticeWorld practice() {
		return PRACTICE;
	}

	public static io.github.flick256.sparbot.drill.DrillManager drills() {
		return DRILLS;
	}

	public static MatchManager matches() {
		return MATCHES;
	}

	public static DebugOverlay debug() {
		return DEBUG;
	}

	public static BotManager bots() {
		return BOTS;
	}
}
