package io.github.flick256.sparbot.stats;

import io.github.flick256.sparbot.SparBot;
import io.github.flick256.sparbot.bot.BotPlayer;
import io.github.flick256.sparbot.record.CombatReviewEvents;
import java.util.IdentityHashMap;
import java.util.Map;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;

/**
 * Feeds vanilla damage and death events into each bot's {@link io.github.flick256.sparbot.core.stats.FightStats}.
 *
 * <p>Fabric's AFTER_DAMAGE reports the amount <i>before</i> armor, enchantments and absorption are
 * applied, so the real damage is measured as the health (plus absorption) the victim actually lost,
 * snapshotted in ALLOW_DAMAGE. AFTER_DAMAGE doesn't fire for a killing blow, so AFTER_DEATH records
 * that hit instead. This listener only observes: it always allows the damage.
 */
public final class StatsTracker {
	private static final Map<LivingEntity, Float> HEALTH_BEFORE = new IdentityHashMap<>();

	private StatsTracker() {
	}

	public static void register() {
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			if (entity instanceof Player || source.getEntity() instanceof Player) {
				HEALTH_BEFORE.put(entity, entity.getHealth() + entity.getAbsorptionAmount());
				CombatReviewEvents.incoming(entity, source, amount);
			}
			return true;
		});
		// Damage cancelled after ALLOW_DAMAGE never reaches AFTER_DAMAGE; drop such snapshots each tick.
		ServerTickEvents.END_SERVER_TICK.register(server -> HEALTH_BEFORE.clear());
		ServerLivingEntityEvents.AFTER_DAMAGE.register(StatsTracker::afterDamage);
		ServerLivingEntityEvents.AFTER_DEATH.register(StatsTracker::afterDeath);
	}

	private static void afterDamage(LivingEntity victim, DamageSource source, float baseDamage, float damageBeforeArmor, boolean blocked) {
		Float before = HEALTH_BEFORE.remove(victim);
		if (before == null) {
			return;
		}
		float lost = Math.max(0, before - Math.max(0, victim.getHealth()) - victim.getAbsorptionAmount());
		CombatReviewEvents.damage(victim, source, lost);
		recordDamage(victim, source, lost);
	}

	private static void recordDamage(LivingEntity victim, DamageSource source, float lost) {
		if (victim instanceof BotPlayer bot) {
			bot.bot().stats().recordDamageTaken(lost);
		}
		// Count only the primary target of the bot's own melee click (not sweeps or other damage it causes).
		if (source.getEntity() instanceof BotPlayer attacker && source.getDirectEntity() == attacker
			&& attacker.bot().isAttacking(victim.getId()) && lost > 0) {
			// Eye to the nearest point of the victim's hitbox: the distance a reach display shows.
			net.minecraft.world.phys.Vec3 eye = attacker.getEyePosition();
			net.minecraft.world.phys.AABB box = victim.getBoundingBox();
			double dx = Math.max(Math.max(box.minX - eye.x, 0), eye.x - box.maxX);
			double dy = Math.max(Math.max(box.minY - eye.y, 0), eye.y - box.maxY);
			double dz = Math.max(Math.max(box.minZ - eye.z, 0), eye.z - box.maxZ);
			attacker.bot().stats().recordHit(lost, attacker.bot().attackWouldCrit(), Math.sqrt(dx * dx + dy * dy + dz * dz));
		}
		if (source.getEntity() instanceof BotPlayer shooter && source.getDirectEntity() instanceof Projectile && victim != shooter && lost > 0) {
			shooter.bot().stats().recordRangedHit(lost);
		}
		// EndCrystal#hurtServer and MinecartTNT#hurtServer blame the explosion on whoever set it off.
		if (source.getEntity() instanceof BotPlayer bomber && source.is(DamageTypeTags.IS_EXPLOSION) && source.getDirectEntity() != bomber
			&& victim != bomber && lost > 0) {
			bomber.bot().stats().recordBlastHit(lost);
		}
	}

	private static void afterDeath(LivingEntity victim, DamageSource source) {
		CombatReviewEvents.death(victim, source);
		Float before = HEALTH_BEFORE.remove(victim);
		if (before != null) {
			CombatReviewEvents.damage(victim, source, before);
			// The killing blow took everything that was left.
			recordDamage(victim, source, before);
		}
		if (victim instanceof BotPlayer bot) {
			bot.bot().stats().recordDeath();
			SparBot.LOGGER.info("Bot {} died: {}", bot.bot().name(), source.getLocalizedDeathMessage(victim).getString());
		}
		// PvP stats: only killing a player (or another bot) counts, not mobs caught in a sweep.
		if (source.getEntity() instanceof BotPlayer killer && killer != victim && victim instanceof Player) {
			killer.bot().stats().recordKill();
		}
	}
}
